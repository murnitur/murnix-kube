import time
import os
import argparse
import threading
import sqlite3
import psutil
import requests
import json
import subprocess
import logging

MURNIX_PATH = "/usr/lib/murnix"

logging.basicConfig(
    filename=f"{MURNIX_PATH}/murnix.log",
    level=logging.ERROR,
    format="%(asctime)s - %(levelname)s - %(message)s",
)


class APIClient:
    def __init__(self, base_url):
        self.base_url = base_url

    def send_metrics(self, metrics: any, model: str, bulk: bool = False):
        endpoint = f"https://api.murnitur.com/api/infrastructures/metrics?model={model}&bulk={bulk}"
        response = requests.post(endpoint, json={"data": metrics})
        return response.status_code == 200 or response.status_code == 201


class SystemMetricsCollector:
    def __init__(self):
        pass

    def get_cpu_metrics(self):
        usage_percentage = psutil.cpu_percent(interval=1)
        cpu_percentage_stats = psutil.cpu_times_percent(interval=1)
        cpu_stats = psutil.cpu_stats()
        cpu_freq = psutil.cpu_freq()
        load_average = psutil.getloadavg()
        return {
            "usage_percentage": usage_percentage,
            "user": cpu_percentage_stats.user if cpu_percentage_stats != None else None,
            "nice": cpu_percentage_stats.nice if cpu_percentage_stats != None else None,
            "system": (
                cpu_percentage_stats.system if cpu_percentage_stats != None else None
            ),
            "idle": cpu_percentage_stats.idle if cpu_percentage_stats != None else None,
            "ctx_switches": cpu_stats.ctx_switches,
            "interrupts": cpu_stats.interrupts,
            "soft_interrupts": cpu_stats.soft_interrupts,
            "syscalls": cpu_stats.syscalls,
            "cpu_freq_min": cpu_freq.min,
            "cpu_freq_max": cpu_freq.max,
            "cpu_freq_current": cpu_freq.current,
            "load_average": load_average,
        }

    def get_virtual_memory_metrics(self):
        virtual_memory = psutil.virtual_memory()
        total = virtual_memory.total
        available = virtual_memory.available
        percent = virtual_memory.percent
        used = virtual_memory.used
        free = virtual_memory.free
        active = virtual_memory.active
        inactive = virtual_memory.inactive
        buffers = virtual_memory.buffers if psutil.LINUX or psutil.BSD else 0
        cached = virtual_memory.cached if psutil.LINUX or psutil.BSD else 0
        shared = virtual_memory.shared if psutil.LINUX or psutil.BSD else 0
        slab = virtual_memory.slab if psutil.LINUX or psutil.BSD else 0
        return {
            "total": total,
            "available": available,
            "percent": percent,
            "used": used,
            "free": free,
            "active": active,
            "inactive": inactive,
            "buffers": buffers,
            "cached": cached,
            "shared": shared,
            "slab": slab,
        }

    def get_swap_memory_metrics(self):
        swap_memory = psutil.swap_memory()
        total = swap_memory.total
        percent = swap_memory.percent
        used = swap_memory.used
        free = swap_memory.free
        sin = swap_memory.sin
        sout = swap_memory.sout
        return {
            "total": total,
            "percent": percent,
            "used": used,
            "free": free,
            "sin": sin,
            "sout": sout,
        }

    def get_disk_usage(self):
        disk_usage = psutil.disk_usage("/")
        return {
            "total": disk_usage.total,
            "percent": disk_usage.percent,
            "used": disk_usage.used,
            "free": disk_usage.free,
        }

    def get_disk_io_counter(self):
        disk_io_counters = psutil.disk_io_counters(nowrap=False)
        return {
            "read_count": disk_io_counters.read_count,
            "write_count": disk_io_counters.write_count,
            "read_bytes": disk_io_counters.read_bytes,
            "write_bytes": disk_io_counters.write_bytes,
            "read_time": disk_io_counters.read_time,
            "write_time": disk_io_counters.write_time,
            "read_merged_count": (
                disk_io_counters.read_merged_count if psutil.BSD or psutil.LINUX else 0
            ),
            "write_merged_count": (
                disk_io_counters.write_merged_count if psutil.BSD or psutil.LINUX else 0
            ),
            "busy_time": (
                disk_io_counters.busy_time if psutil.BSD or psutil.LINUX else 0
            ),
        }

    def get_network_metrics(self, kind: str):
        try:
            sconns = psutil.net_connections(kind)
            connections = []
            for sconn in sconns:
                connections.append(
                    {
                        "local_address": sconn.laddr,
                        "remote_address": sconn.raddr,
                        "status": sconn.status,
                        "pid": sconn.pid,
                    }
                )
            return connections
        except Exception as e:
            logging.error('An error occured: %s', str(e), exc_info=True)
            return []

    def get_network_io_counters(self):
        try:
            io_counters = []
            net_io_counters = psutil.net_io_counters(pernic=True, nowrap=False)
            for interface, counters in net_io_counters.items():
                io_counters.append(
                    {
                        "interface": interface,
                        "bytes_sent": counters.bytes_sent,
                        "bytes_recv": counters.bytes_recv,
                        "packets_sent": counters.packets_sent,
                        "packets_recv": counters.packets_recv,
                        "errout": counters.errout,
                        "errin": counters.errin,
                        "dropout": counters.dropout,
                        "dropin": counters.dropin,
                    }
                )
            return io_counters
        except Exception as e:
            logging.error('An error occured: %s', str(e), exc_info=True)
            return []

    def get_network_if_stats(self):
        try:
            if_stats = []
            net_if_stats = psutil.net_if_stats()
            for interface, stat in net_if_stats.items():
                if_stats.append(
                    {
                        "interface": interface,
                        "isup": stat.isup,
                        "speed": stat.speed,
                        "mtu": stat.mtu,
                        "flags": stat.flags,
                    }
                )
            return if_stats
        except Exception as e:
            logging.error('An error occured: %s', str(e), exc_info=True)
            return []

    def get_network_if_addrs(self):
        try:
            if_addresses = []
            net_if_addresses = psutil.net_if_addrs()
            for interface, address in net_if_addresses.items():
                for addr in address:
                    if_addresses.append(
                        {
                            "interface": interface,
                            "address": addr.address,
                            "netmask": addr.netmask,
                            "broadcast": addr.broadcast,
                            "ptp": addr.ptp,
                        }
                    )
            return if_addresses
        except Exception as e:
            logging.error('An error occured: %s', str(e), exc_info=True)
            return []

    def get_system_fans(self):
        fans = []
        system_fans = psutil.sensors_fans() if psutil.BSD or psutil.LINUX else {}

        for model, sfans in system_fans:
            for fan in sfans:
                fans.append(
                    {"model": model, "label": fan.label, "current": fan.current}
                )

        return fans

    def get_system_temperatures(self):
        temperatures = []
        system_temperatures = (
            psutil.sensors_temperatures() if psutil.BSD or psutil.LINUX else {}
        )

        for model, shw_temps in system_temperatures:
            for shw_temp in shw_temps:
                temperatures.append(
                    {
                        "model": model,
                        "label": shw_temp.label,
                        "current": shw_temp.current,
                        "high": shw_temp.high,
                        "critical": shw_temp.critical,
                    }
                )

        return temperatures

    def get_system_battery(self):
        battery = psutil.sensors_battery()
        return (
            {
                "percent": battery.percent,
                "secsleft": battery.secsleft,
                "power_plugged": battery.power_plugged,
            }
            if battery != None
            else None
        )


class Config:
    API_BASE_URL = "https://api.murnitur.com/api"

    TABLE_CREATE = {
        "cpu_metrics": """CREATE TABLE IF NOT EXISTS cpu_metrics
    (timestamp INTEGER, project_id STRING, monitor_id STRING, usage_percentage REAL, 
    user REAL, nice REAL, system REAL, idle REAL, ctx_switches INTEGER, interrupts INTEGER, 
    soft_interrupts INTEGER, syscalls INTEGER, cpu_freq_min REAL, cpu_freq_max REAL, 
    cpu_freq_current REAL, load_average STRING)""",
        "fans": """CREATE TABLE IF NOT EXISTS fans
    (timestamp INTEGER, project_id STRING, monitor_id STRING, model STRING, 
    label STRING, current REAL)""",
        "batteries": """CREATE TABLE IF NOT EXISTS batteries
    (timestamp INTEGER, project_id STRING, monitor_id STRING, percent REAL, 
    secsleft REAL, power_plugged BOOLEAN)""",
        "temperatures": """CREATE TABLE IF NOT EXISTS temperatures
    (timestamp INTEGER, project_id STRING, monitor_id STRING, model STRING, 
    label STRING, current REAL, high REAL, critical REAL)""",
        "network_metrics": """CREATE TABLE IF NOT EXISTS network_metrics
    (timestamp INTEGER, project_id STRING, monitor_id STRING, local_address STRING, 
    remote_address STRING, status STRING, pid INTEGER)""",
        "network_if_metrics": """CREATE TABLE IF NOT EXISTS network_if_metrics
    (timestamp INTEGER, project_id STRING, monitor_id STRING, interface STRING, 
    isup BOOLEAN, speed REAL, mtu REAL, flags STRING)""",
        "network_if_address_metrics": """CREATE TABLE IF NOT EXISTS network_if_address_metrics
    (timestamp INTEGER, project_id STRING, monitor_id STRING, interface STRING, 
    address STRING, netmask STRING, broadcast STRING, ptp STRING)""",
        "io_counters": """CREATE TABLE IF NOT EXISTS io_counters 
    (timestamp INTEGER, project_id STRING, monitor_id STRING, read_count REAL, 
    write_count REAL, read_bytes REAL, write_bytes REAL, read_time REAL, 
    write_time REAL, read_merged_count REAL, write_merged_count REAL, busy_time REAL)""",
        "net_io_counters": """CREATE TABLE IF NOT EXISTS net_io_counters 
    (timestamp INTEGER, project_id STRING, monitor_id STRING, interface STRING, 
    bytes_sent REAL, bytes_recv REAL, packets_sent REAL, packets_recv REAL, 
    errout REAL, errin REAL, dropout REAL, dropin REAL)""",
        "virtual_memories": """CREATE TABLE IF NOT EXISTS virtual_memories 
    (timestamp INTEGER, project_id STRING, monitor_id STRING, total REAL, 
    available REAL, percent REAL, used REAL, free REAL, active REAL, 
    inactive REAL, buffers REAL, cached REAL, shared REAL, slab REAL)""",
        "swap_memories": """CREATE TABLE IF NOT EXISTS swap_memories 
    (timestamp INTEGER, project_id STRING, monitor_id STRING, total REAL, 
    percent REAL, used REAL, free REAL, sin REAL, sout REAL)""",
        "disk_usage": """CREATE TABLE IF NOT EXISTS disk_usage 
    (timestamp INTEGER, project_id STRING, monitor_id STRING, total REAL, 
    percent REAL, used REAL, free REAL)""",
    }


class NS:
    def __init__(self, project_id, monitor_id, frequency, interval):
        self.project_id = project_id
        self.monitor_id = monitor_id
        self.frequency = frequency
        self.interval = interval


def detach_from_terminal():
    """
    Detach the process from the terminal.
    """
    if os.fork() > 0:
        os._exit(0)


def init_command(args):
    """
    Initialize monitoring based on the provided arguments.
    """
    if args.monitor_id and args.project_id:

        start_collections(args)

        thread = threading.Thread(
            name=args.project_id,
            daemon=True,
            target=send_metrics,
            args=(
                args.monitor_id,
                args.project_id,
            ),
        )
        thread.start()


api = APIClient(Config.API_BASE_URL)


def send_metrics(monitor_id, project_id):
    while True:
        try:
            send_battery_metrics()
            send_cpu_metrics()
            send_temperature_metrics()
            send_fan_metrics()
            send_network_metrics()
            send_network_if_metrics()
            send_network_if_address_metrics()
            send_net_io_counter_metrics()
            send_virtual_memory_metrics()
            send_swap_memory_metrics()
            send_disk_usage_metrics()
            send_io_counters_metrics()

            logs = get_logs(monitor_id, project_id)
            api.send_metrics(logs, "logs", True)

        except Exception as e:
            logging.error(f"Error in API Call: {e}")
            pass

        time.sleep(600)


def send_io_counters_metrics():
    conn = sqlite3.connect(f"{MURNIX_PATH}/io_counters.db")
    c = conn.cursor()
    c.execute("SELECT * FROM io_counters")
    metrics = c.fetchall()
    io_counters = []
    for metric in metrics:
        io_counters.append(
            {
                "timestamp": metric[0],
                "project_id": metric[1],
                "monitor_id": metric[2],
                "readCount": metric[3],
                "writeCount": metric[4],
                "readBytes": metric[5],
                "writeBytes": metric[6],
                "readTime": metric[7],
                "writeTime": metric[8],
                "readMergedCount": metric[9],
                "writeMergedCount": metric[10],
                "busyTime": metric[11],
            }
        )
    api.send_metrics(io_counters, "disk_io_counter", bulk=True)
    c.execute("DELETE FROM io_counters")
    conn.commit()
    conn.close()


def send_disk_usage_metrics():
    conn = sqlite3.connect(f"{MURNIX_PATH}/disk_usage.db")
    c = conn.cursor()
    c.execute("SELECT * FROM disk_usage")
    metrics = c.fetchall()
    disk_usage = []
    for metric in metrics:
        disk_usage.append(
            {
                "timestamp": metric[0],
                "project_id": metric[1],
                "monitor_id": metric[2],
                "total": metric[3],
                "percent": metric[4],
                "used": metric[5],
                "free": metric[6],
            }
        )
    api.send_metrics(disk_usage, "disk_usage", bulk=True)
    c.execute("DELETE FROM disk_usage")
    conn.commit()
    conn.close()


def send_swap_memory_metrics():
    conn = sqlite3.connect(f"{MURNIX_PATH}/swap_memories.db")
    c = conn.cursor()
    c.execute("SELECT * FROM swap_memories")
    metrics = c.fetchall()
    swap_memories = []
    for metric in metrics:
        swap_memories.append(
            {
                "timestamp": metric[0],
                "project_id": metric[1],
                "monitor_id": metric[2],
                "total": metric[3],
                "percent": metric[4],
                "used": metric[5],
                "free": metric[6],
                "sin": metric[7],
                "sout": metric[8],
            }
        )
    api.send_metrics(swap_memories, "swap_memory", bulk=True)
    c.execute("DELETE FROM swap_memories")
    conn.commit()
    conn.close()


def send_virtual_memory_metrics():
    conn = sqlite3.connect(f"{MURNIX_PATH}/virtual_memories.db")
    c = conn.cursor()
    c.execute("SELECT * FROM virtual_memories")
    metrics = c.fetchall()
    virtual_memories = []
    for metric in metrics:
        virtual_memories.append(
            {
                "timestamp": metric[0],
                "project_id": metric[1],
                "monitor_id": metric[2],
                "total": metric[3],
                "available": metric[4],
                "percent": metric[5],
                "used": metric[6],
                "free": metric[7],
                "active": metric[8],
                "inactive": metric[9],
                "buffers": metric[10],
                "cached": metric[11],
                "shared": metric[12],
                "slab": metric[13],
            }
        )
    api.send_metrics(virtual_memories, "virtual_memory", bulk=True)
    c.execute("DELETE FROM virtual_memories")
    conn.commit()
    conn.close()


def send_net_io_counter_metrics():
    conn = sqlite3.connect(f"{MURNIX_PATH}/net_io_counters.db")
    c = conn.cursor()
    c.execute("SELECT * FROM net_io_counters")
    metrics = c.fetchall()
    net_io_counters = []
    for metric in metrics:
        net_io_counters.append(
            {
                "timestamp": metric[0],
                "project_id": metric[1],
                "monitor_id": metric[2],
                "interface": metric[3],
                "bytes_sent": metric[4],
                "bytes_recv": metric[5],
                "packets_sent": metric[6],
                "packets_recv": metric[7],
                "errout": metric[8],
                "errin": metric[9],
                "dropout": metric[10],
                "dropin": metric[11],
            }
        )
    api.send_metrics(net_io_counters, "network_io_counter", bulk=True)
    c.execute("DELETE FROM net_io_counters")
    conn.commit()
    conn.close()


def send_network_if_address_metrics():
    conn = sqlite3.connect(f"{MURNIX_PATH}/network_if_address_metrics.db")
    c = conn.cursor()
    c.execute("SELECT * FROM network_if_address_metrics")
    metrics = c.fetchall()
    network_if_address_metrics = []
    for metric in metrics:
        network_if_address_metrics.append(
            {
                "timestamp": metric[0],
                "project_id": metric[1],
                "monitor_id": metric[2],
                "interface": metric[3],
                "address": metric[4],
                "netmask": metric[5],
                "broadcast": metric[6],
                "ptp": metric[7],
            }
        )
    api.send_metrics(network_if_address_metrics, "network_interface_address", bulk=True)
    c.execute("DELETE FROM network_if_address_metrics")
    conn.commit()
    conn.close()


def send_network_if_metrics():
    conn = sqlite3.connect(f"{MURNIX_PATH}/network_if_metrics.db")
    c = conn.cursor()
    c.execute("SELECT * FROM network_if_metrics")
    metrics = c.fetchall()
    network_if_metrics = []
    for metric in metrics:
        network_if_metrics.append(
            {
                "timestamp": metric[0],
                "project_id": metric[1],
                "monitor_id": metric[2],
                "interface": metric[3],
                "isup": metric[4],
                "speed": metric[5],
                "mtu": metric[6],
                "flags": metric[7],
            }
        )
    api.send_metrics(network_if_metrics, "interface_stat", bulk=True)
    c.execute("DELETE FROM network_if_metrics")
    conn.commit()
    conn.close()


def send_network_metrics():
    conn = sqlite3.connect(f"{MURNIX_PATH}/network_metrics.db")
    c = conn.cursor()
    c.execute("SELECT * FROM network_metrics")
    metrics = c.fetchall()
    network_metrics = []
    for metric in metrics:
        network_metrics.append(
            {
                "timestamp": metric[0],
                "project_id": metric[1],
                "monitor_id": metric[2],
                "local_address": metric[3].split(","),
                "remote_address": metric[4].split(","),
                "status": metric[5],
                "pid": metric[6],
            }
        )
    api.send_metrics(network_metrics, "network_metric", bulk=True)
    c.execute("DELETE FROM network_metrics")
    conn.commit()
    conn.close()


def send_battery_metrics():
    conn = sqlite3.connect(f"{MURNIX_PATH}/batteries.db")
    c = conn.cursor()
    c.execute("SELECT * FROM batteries")
    metrics = c.fetchall()
    batteries = []
    for metric in metrics:
        batteries.append(
            {
                "timestamp": metric[0],
                "project_id": metric[1],
                "monitor_id": metric[2],
                "percent": metric[3],
                "secsleft": metric[4],
                "powerPlugged": metric[5],
            }
        )
    api.send_metrics(batteries, "system_battery", bulk=True)
    c.execute("DELETE FROM batteries")
    conn.commit()
    conn.close()


def send_fan_metrics():
    conn = sqlite3.connect(f"{MURNIX_PATH}/fans.db")
    c = conn.cursor()
    c.execute("SELECT * FROM fans")
    metrics = c.fetchall()
    fans = []
    for metric in metrics:
        fans.append(
            {
                "timestamp": metric[0],
                "project_id": metric[1],
                "monitor_id": metric[2],
                "model": metric[3],
                "label": metric[4],
                "current": metric[5],
            }
        )
    api.send_metrics(fans, "system_fan", bulk=True)
    c.execute("DELETE FROM fans")
    conn.commit()
    conn.close()


def send_temperature_metrics():
    conn = sqlite3.connect(f"{MURNIX_PATH}/temperatures.db")
    c = conn.cursor()
    c.execute("SELECT * FROM temperatures")
    metrics = c.fetchall()
    temperatures = []
    for metric in metrics:
        temperatures.append(
            {
                "timestamp": metric[0],
                "project_id": metric[1],
                "monitor_id": metric[2],
                "model": metric[3],
                "label": metric[4],
                "current": metric[5],
                "high": metric[6],
                "critical": metric[7],
            }
        )
    api.send_metrics(temperatures, "system_temperature", bulk=True)
    c.execute("DELETE FROM temperatures")
    conn.commit()
    conn.close()


def send_cpu_metrics():
    conn = sqlite3.connect(f"{MURNIX_PATH}/cpu_metrics.db")
    c = conn.cursor()
    c.execute("SELECT * FROM cpu_metrics")
    metrics = c.fetchall()
    cpus = []
    for metric in metrics:
        cpus.append(
            {
                "timestamp": metric[0],
                "project_id": metric[1],
                "monitor_id": metric[2],
                "usage_percentage": metric[3],
                "user": metric[4],
                "nice": metric[5],
                "system": metric[6],
                "idle": metric[7],
                "ctx_switches": metric[8],
                "interrupts": metric[9],
                "soft_interrupts": metric[10],
                "syscalls": metric[11],
                "cpu_freq_min": metric[12],
                "cpu_freq_max": metric[13],
                "cpu_freq_current": metric[14],
                "load_average": metric[15].split(","),
            }
        )
    api.send_metrics(cpus, "cpu_stat", bulk=True)
    c.execute("DELETE FROM cpu_metrics")
    conn.commit()
    conn.close()


def start_collections(args):
    interval = int(args.interval) if int(args.interval) > 0 else 1
    thread = threading.Thread(
        name=args.monitor_id,
        daemon=True,
        target=collect_metric,
        args=(args.monitor_id, args.project_id, interval),
    )
    thread.start()


def collect_metric(monitor_id, project_id, interval):
    while True:
        try:
            collector = SystemMetricsCollector()
            cpu_metrics = collector.get_cpu_metrics()
            virtual_memory = collector.get_virtual_memory_metrics()
            swap_memory = collector.get_swap_memory_metrics()
            disk_usage = collector.get_disk_usage()
            io_counters = collector.get_disk_io_counter()
            network_metrics = collector.get_network_metrics("tcp")
            if_stats = collector.get_network_if_stats()
            if_addresses = collector.get_network_if_addrs()
            net_io_counters = collector.get_network_io_counters()
            fans = collector.get_system_fans()
            temps = collector.get_system_temperatures()
            battery = collector.get_system_battery()

            store_cpu_stats("cpu_metrics", cpu_metrics, monitor_id, project_id)
            store_virtual_memory_stats(
                "virtual_memories", virtual_memory, monitor_id, project_id
            )
            store_swap_memory_stats(
                "swap_memories", swap_memory, monitor_id, project_id
            )
            store_disk_usage("disk_usage", disk_usage, monitor_id, project_id)
            store_io_counters_stats("io_counters", io_counters, monitor_id, project_id)
            store_net_io_counters_stats(
                "net_io_counters", net_io_counters, monitor_id, project_id
            )
            store_network_stats(
                "network_metrics", network_metrics, monitor_id, project_id
            )
            store_network_if_stats(
                "network_if_metrics", if_stats, monitor_id, project_id
            )
            store_network_if_address_stats(
                "network_if_address_metrics", if_addresses, monitor_id, project_id
            )
            store_temperature_stats("temperatures", temps, monitor_id, project_id)
            store_fan_stats("fans", fans, monitor_id, project_id)
            store_battery_stats("batteries", battery, monitor_id, project_id)
        except Exception as e:
            logging.error('An error occured: %s', str(e), exc_info=True)
        time.sleep(interval * 60)


def joined_strings(t):
    s = ""
    for e in t:
        s += str(e) + ","
    s = s[:-1]
    return s


def store_cpu_stats(table: str, metrics: any, monitor_id: str, project_id: str):
    load_average = joined_strings(metrics["load_average"])

    conn = sqlite3.connect(f"{MURNIX_PATH}/" + table + ".db")
    c = conn.cursor()
    c.execute(Config.TABLE_CREATE.get(table))
    timestamp = int(time.time()) * 1000
    c.execute(
        "INSERT INTO {table} VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)".format(
            table=table,
        ),
        (
            timestamp,
            project_id,
            monitor_id,
            metrics["usage_percentage"],
            metrics["user"],
            metrics["nice"],
            metrics["system"],
            metrics["idle"],
            metrics["ctx_switches"],
            metrics["interrupts"],
            metrics["soft_interrupts"],
            metrics["syscalls"],
            metrics["cpu_freq_min"],
            metrics["cpu_freq_max"],
            metrics["cpu_freq_current"],
            load_average,
        ),
    )
    conn.commit()
    conn.close()


def store_virtual_memory_stats(
    table: str, metrics: any, monitor_id: str, project_id: str
):
    conn = sqlite3.connect(f"{MURNIX_PATH}/" + table + ".db")
    c = conn.cursor()
    c.execute(Config.TABLE_CREATE.get(table))
    timestamp = int(time.time()) * 1000
    c.execute(
        "INSERT INTO {table} VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)".format(
            table=table,
        ),
        (
            timestamp,
            project_id,
            monitor_id,
            metrics["total"],
            metrics["available"],
            metrics["percent"],
            metrics["used"],
            metrics["free"],
            metrics["active"],
            metrics["inactive"],
            metrics["buffers"],
            metrics["cached"],
            metrics["shared"],
            metrics["slab"],
        ),
    )
    conn.commit()
    conn.close()


def store_swap_memory_stats(table: str, metrics: any, monitor_id: str, project_id: str):
    conn = sqlite3.connect(f"{MURNIX_PATH}/" + table + ".db")
    c = conn.cursor()
    c.execute(Config.TABLE_CREATE.get(table))
    timestamp = int(time.time()) * 1000
    c.execute(
        "INSERT INTO {table} VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)".format(
            table=table,
        ),
        (
            timestamp,
            project_id,
            monitor_id,
            metrics["total"],
            metrics["percent"],
            metrics["used"],
            metrics["free"],
            metrics["sin"],
            metrics["sout"],
        ),
    )
    conn.commit()
    conn.close()


def store_disk_usage(table: str, metrics: any, monitor_id: str, project_id: str):
    conn = sqlite3.connect(f"{MURNIX_PATH}/" + table + ".db")
    c = conn.cursor()
    c.execute(Config.TABLE_CREATE.get(table))
    timestamp = int(time.time()) * 1000
    c.execute(
        "INSERT INTO {table} VALUES (?, ?, ?, ?, ?, ?, ?)".format(
            table=table,
        ),
        (
            timestamp,
            project_id,
            monitor_id,
            metrics["total"],
            metrics["percent"],
            metrics["used"],
            metrics["free"],
        ),
    )
    conn.commit()
    conn.close()


def store_io_counters_stats(table: str, metrics: any, monitor_id: str, project_id: str):
    conn = sqlite3.connect(f"{MURNIX_PATH}/" + table + ".db")
    c = conn.cursor()
    c.execute(Config.TABLE_CREATE.get(table))
    timestamp = int(time.time()) * 1000
    c.execute(
        "INSERT INTO {table} VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)".format(
            table=table,
        ),
        (
            timestamp,
            project_id,
            monitor_id,
            metrics["read_count"],
            metrics["write_count"],
            metrics["read_bytes"],
            metrics["write_bytes"],
            metrics["read_time"],
            metrics["write_time"],
            metrics["read_merged_count"],
            metrics["write_merged_count"],
            metrics["busy_time"],
        ),
    )
    conn.commit()
    conn.close()


def store_net_io_counters_stats(
    table: str, metrics: any, monitor_id: str, project_id: str
):
    conn = sqlite3.connect(f"{MURNIX_PATH}/" + table + ".db")
    c = conn.cursor()
    c.execute(Config.TABLE_CREATE.get(table))
    for metric in metrics:
        timestamp = int(time.time()) * 1000
        c.execute(
            "INSERT INTO {table} VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)".format(
                table=table,
            ),
            (
                timestamp,
                project_id,
                monitor_id,
                metric["interface"],
                metric["bytes_sent"],
                metric["bytes_recv"],
                metric["packets_sent"],
                metric["packets_recv"],
                metric["errout"],
                metric["errin"],
                metric["dropout"],
                metric["dropin"],
            ),
        )
    conn.commit()
    conn.close()


def store_network_stats(table: str, metrics: any, monitor_id: str, project_id: str):
    conn = sqlite3.connect(f"{MURNIX_PATH}/" + table + ".db")
    c = conn.cursor()
    c.execute(Config.TABLE_CREATE.get(table))
    for metric in metrics:
        timestamp = int(time.time()) * 1000
        c.execute(
            "INSERT INTO {table} VALUES (?, ?, ?, ?, ?, ?, ?)".format(
                table=table,
            ),
            (
                timestamp,
                project_id,
                monitor_id,
                joined_strings(metric["local_address"]),
                joined_strings(metric["remote_address"]),
                metric["status"],
                metric["pid"],
            ),
        )
    conn.commit()
    conn.close()


def store_network_if_stats(table: str, metrics: any, monitor_id: str, project_id: str):
    conn = sqlite3.connect(f"{MURNIX_PATH}/" + table + ".db")
    c = conn.cursor()
    c.execute(Config.TABLE_CREATE.get(table))
    for metric in metrics:
        timestamp = int(time.time()) * 1000
        c.execute(
            "INSERT INTO {table} VALUES (?, ?, ?, ?, ?, ?, ?)".format(
                table=table,
            ),
            (
                timestamp,
                project_id,
                monitor_id,
                metric["interface"],
                metric["isup"],
                metric["speed"],
                metric["mtu"],
                metric["flags"],
            ),
        )
    conn.commit()
    conn.close()


def store_network_if_address_stats(
    table: str, metrics: any, monitor_id: str, project_id: str
):
    conn = sqlite3.connect(f"{MURNIX_PATH}/" + table + ".db")
    c = conn.cursor()
    c.execute(Config.TABLE_CREATE.get(table))
    for metric in metrics:
        timestamp = int(time.time()) * 1000
        c.execute(
            "INSERT INTO {table} VALUES (?, ?, ?, ?, ?, ?, ?, ?)".format(
                table=table,
            ),
            (
                timestamp,
                project_id,
                monitor_id,
                metric["interface"],
                metric["address"],
                metric["netmask"],
                metric["broadcast"],
                metric["ptp"],
            ),
        )
    conn.commit()
    conn.close()


def store_fan_stats(table: str, metrics: any, monitor_id: str, project_id: str):
    conn = sqlite3.connect(f"{MURNIX_PATH}/" + table + ".db")
    c = conn.cursor()
    c.execute(Config.TABLE_CREATE.get(table))
    for metric in metrics:
        timestamp = int(time.time()) * 1000
        c.execute(
            "INSERT INTO {table} VALUES (?, ?, ?, ?, ?, ?)".format(
                table=table,
            ),
            (
                timestamp,
                project_id,
                monitor_id,
                metric["model"],
                metric["label"],
                metric["current"],
            ),
        )
    conn.commit()
    conn.close()


def store_temperature_stats(table: str, metrics: any, monitor_id: str, project_id: str):
    conn = sqlite3.connect(f"{MURNIX_PATH}/" + table + ".db")
    c = conn.cursor()
    c.execute(Config.TABLE_CREATE.get(table))
    for metric in metrics:
        timestamp = int(time.time()) * 1000
        c.execute(
            "INSERT INTO {table} VALUES (?, ?, ?, ?, ?, ?, ?, ?)".format(
                table=table,
            ),
            (
                timestamp,
                project_id,
                monitor_id,
                metric["model"],
                metric["label"],
                metric["current"],
                metric["high"],
                metric["critical"],
            ),
        )
    conn.commit()
    conn.close()


def store_battery_stats(table: str, metrics: any, monitor_id: str, project_id: str):
    conn = sqlite3.connect(f"{MURNIX_PATH}/" + table + ".db")
    c = conn.cursor()
    c.execute(Config.TABLE_CREATE.get(table))
    timestamp = int(time.time()) * 1000
    if metrics is not None:
        c.execute(
            "INSERT INTO {table} VALUES (?, ?, ?, ?, ?, ?)".format(
                table=table,
            ),
            (
                timestamp,
                project_id,
                monitor_id,
                metrics["percent"],
                metrics["secsleft"],
                metrics["power_plugged"],
            ),
        )
    conn.commit()
    conn.close()


threading.Thread.stopped = False


def main():
    conn = sqlite3.connect(f"{MURNIX_PATH}/config.db")

    c = conn.cursor()
    c.execute(
        "CREATE TABLE IF NOT EXISTS config (timestamp INTEGER, project_id STRING, monitor_id STRING, frequency STRING, interval STRING)"
    )

    for conf in Config.TABLE_CREATE:
        con = sqlite3.connect(f"{MURNIX_PATH}/{conf}.db")
        q = con.cursor()
        q.execute(Config.TABLE_CREATE.get(conf))
        con.commit()
        con.close()

    parser = argparse.ArgumentParser(description="Monitor Server")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    subparsers.add_parser(
        "logs", help="Display logs from Murnix"
    )
    subparsers.add_parser(
        "start", help="Start monitoring from config file"
    )
    parser_init = subparsers.add_parser("init", help="Initialize monitoring")
    parser_init.add_argument(
        "--monitor-id",
        help="Monitoring ID for initialization",
    )
    parser_init.add_argument(
        "--project-id",
        help="Project ID for initialization",
    )
    parser_init.add_argument(
        "-i",
        "--interface",
        help="The interval, expressed in minutes, for fetching metrics. The default setting is 1 minute.",
        dest="interval",
        default=1,
    )
    parser_init.add_argument(
        "-f",
        "--frequency",
        help="The desired synchronization frequency for metric updates with Murnitur.",
        dest="frequency",
        default="hourly",
        choices=["hourly", "daily", "weekly"],
    )

    args = parser.parse_args()

    if args.command == "init":
        if not hasattr(args, "monitor_id"):
            parser.error("[-] --monitor-id is required, use --help for more info.")
        elif not hasattr(args, "project_id"):
            parser.error("[-] --project-id is required, use --help for more info.")
        else:
            timestamp = int(time.time()) * 1000
            c.execute(
                "SELECT COUNT(*) FROM config WHERE monitor_id = ?", (args.monitor_id,)
            )
            count = c.fetchone()[0]
            if count == 0:
                c.execute(
                    "INSERT INTO config VALUES (?, ?, ?, ?, ?)",
                    (
                        timestamp,
                        args.project_id,
                        args.monitor_id,
                        args.frequency,
                        args.interval,
                    ),
                )
                conn.commit()
                conn.close()

            detach_from_terminal()

            init_command(args)

            logging.debug("Murnix initialized successfully.")

            while True:
                time.sleep(1)

    elif args.command == "start":
        configs = read_config()

        if len(configs) > 0:
            logging.debug(configs[0])
        else:
            print("No configurations found. Exiting.")
            logging.warning("No configurations found. Exiting.")
            os._exit(1)

        # detach_from_terminal()

        for config in configs:
            ns = NS(config[1], config[2], config[3], config[4])

            init_command(ns)
        logging.debug("Murnix initialized from config.")

        while True:
            time.sleep(1)

    elif args.command == "logs":
        entries = subprocess.run(
            ["cat", "/usr/lib/murnix/murnix.log"],
            capture_output=True,
            text=True,
        )
        result = entries.stdout
        print(result)
    # while True:
    #     time.sleep(1)


def read_config():
    conn = sqlite3.connect(f"{MURNIX_PATH}/config.db")
    c = conn.cursor()
    c.execute("SELECT * FROM config")
    config = c.fetchall()
    conn.commit()
    conn.close()
    return config


def get_logs(monitor_id, project_id):
    syslog_priority = {
        "0": "Emergency",
        "1": "Alert",
        "2": "Critical",
        "3": "Error",
        "4": "Warning",
        "5": "Notice",
        "6": "Informational",
        "7": "Debug",
    }
    entries = subprocess.run(
        ["journalctl", "-o", "json", "--since", "10 minutes ago"],
        capture_output=True,
        text=True,
    )
    result = entries.stdout

    logs = []
    for log in result.splitlines():
        log_entry = json.loads(log)
        if log_entry is not None:
            logs.append(
                {
                    "level": log_entry.get("PRIORITY"),
                    "timestamp": int(log_entry.get("__REALTIME_TIMESTAMP"))/1000,
                    "message": log_entry.get("MESSAGE"),
                    "type": syslog_priority[log_entry.get("PRIORITY")],
                    "pid": log_entry.get("_PID"),
                    "project_id": project_id,
                    "monitor_id": monitor_id,
                }
            )

    return logs


if __name__ == "__main__":
    main()
